#!/bin/bash
set -euo pipefail

KERNEL_IMG=/home/wq7/workspace/driver-lab/kernel-src/linux-5.15.10/output/x86/bzImage
ROOTFS=/tmp/day01_net.img
REC=/home/wq7/records/vhost_test2

cleanup() { pkill -9 qemu-system 2>/dev/null || true; }
trap cleanup EXIT

run_test() {
    local vhost_flag=$1
    local label=$2
    cleanup; sleep 2

    mkdir -p $REC/$label
    : > $REC/$label/run.log

    echo "=== Running $label vhost=$vhost_flag ===" | tee -a $REC/$label/run.log

    qemu-system-x86_64 \
        -kernel "$KERNEL_IMG" \
        -nographic \
        -append "console=ttyS0" \
        -netdev tap,id=net0,ifname=tap-vnet0,script=no,downscript=no,vhost=$vhost_flag \
        -device virtio-net-pci,netdev=net0,mac=52:54:00:12:34:56 \
        -initrd "$ROOTFS" \
        >> $REC/$label/run.log 2>&1 &

    QEMU_PID=$!
    sleep 18
    kill $QEMU_PID 2>/dev/null || true
    wait $QEMU_PID 2>/dev/null || true
    sleep 1

    ip -br link > $REC/$label/ip_br_link.txt 2>&1 || true
    ip addr > $REC/$label/ip_addr.txt 2>&1 || true
    bridge link > $REC/$label/bridge_link.txt 2>&1 || true
    bridge fdb show > $REC/$label/bridge_fdb.txt 2>&1 || true
    lsmod | grep -E "vhost|tun|bridge" > $REC/$label/modules.txt 2>&1 || true
    ls -l /dev/vhost-net /dev/net/tun > $REC/$label/dev_nodes.txt 2>&1 || true
    ps -ef | grep "[q]emu" > $REC/$label/qemu_process.txt 2>&1 || true

    echo "=== $label done ===" | tee -a $REC/$label/run.log
}

mkdir -p $REC/off_test $REC/on_test

echo "=== vhost=off ===" | tee $REC/run.log
run_test off off_test
grep -E "init|ping|PING|bytes|round-trip|Kernel panic" $REC/off_test/run.log | grep -v "Booting|Command line|x86/fpu" | head -15

echo ""
echo "=== vhost=on ===" | tee -a $REC/run.log
run_test on on_test
grep -E "init|ping|PING|bytes|round-trip|Kernel panic|Permission|vhost" $REC/on_test/run.log | grep -v "Booting|Command line|x86/fpu" | head -15

echo ""
echo "ALL DONE"
