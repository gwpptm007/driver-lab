/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _NETDEV_STAGE07_COMPAT_H_
#define _NETDEV_STAGE07_COMPAT_H_

#include <linux/version.h>
#include <linux/netdevice.h>

/*
 * 统一收敛 stage07 需要的兼容差异。
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 8, 0)
#define STAGE07_NETIF_NAPI_ADD(ndev, napi, pollfn, weight) \
	netif_napi_add_weight((ndev), (napi), (pollfn), (weight))
#else
#define STAGE07_NETIF_NAPI_ADD(ndev, napi, pollfn, weight) \
	netif_napi_add((ndev), (napi), (pollfn), (weight))
#endif

#endif /* _NETDEV_STAGE07_COMPAT_H_ */
