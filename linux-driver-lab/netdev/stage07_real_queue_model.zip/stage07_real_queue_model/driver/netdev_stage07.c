// SPDX-License-Identifier: GPL-2.0
/*
 * netdev_stage07.c — stage07 real queue model 第一版落地实现
 *
 * 【本阶段目标】
 * stage04 的重点是：ring + DMA + RX replenishment。
 * stage07 的重点是：
 *   1. 明确 TX submit / notify / complete 的边界
 *   2. 明确 RX post / device-write / consume / refill 的闭环
 *   3. 用 submit_idx / notify_idx / complete_idx / post_idx / device_idx / consume_idx
 *      六个 index，把“谁生产、谁消费、谁通知、谁回收”讲清楚
 *
 * 【总体模型】
 *
 *   CPU(TX)                               device/backend                      CPU(NAPI)
 *     |                                         |                                 |
 *     | ndo_start_xmit()                        |                                 |
 *     |  1. tx submit_idx -> SUBMITTED          |                                 |
 *     |  2. tx_inflight++                       |                                 |
 *     |---------------------------------------->| stage07_notify_device()         |
 *     |                                         | 3. notify_idx -> 取 TX 请求     |
 *     |                                         | 4. device_idx -> 取 POSTED RX   |
 *     |                                         | 5. memcpy(TX -> RX buffer)      |
 *     |                                         | 6. TX 标 DONE / RX 标 DONE      |
 *     |                                         | 7. raise irq / schedule napi    |
 *     |                                         |-------------------------------->|
 *     |                                         |                                 | 8. complete_idx 回收 TX
 *     |                                         |                                 | 9. consume_idx 消费 RX
 *     |                                         |                                 | 10. post_idx 重新 refill RX
 *
 * 【与 stage04 的主要区别】
 * - stage04: tx_prod / rx_hw_pos / rx_poll_pos，重点是 descriptor 和 replenishment
 * - stage07: 显式拆出 queue lifecycle，强调 CPU/device/CPU 的边界
 *
 * 【当前版本边界】
 * - 单 TX queue + 单 RX queue + 单 NAPI
 * - 仍是教学型“伪设备”，用 memcpy 模拟 device DMA copy
 * - 不做多队列 / RSS / offload / XDP
 */

#include <linux/debugfs.h>
#include <linux/dma-mapping.h>
#include <linux/etherdevice.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/netdevice.h>
#include <linux/seq_file.h>
#include <linux/skbuff.h>
#include <linux/spinlock.h>
#include <linux/version.h>

#include "../include/netdev_stage07_compat.h"

#define DRV_NAME "netdev_stage07"
#define STAGE07_DEFAULT_RING_SIZE 128
#define STAGE07_DEFAULT_NAPI_WEIGHT 32
#define STAGE07_DEFAULT_RX_BUF_SIZE 2048
#define STAGE07_MAX_QUEUE_DUMP 16

enum stage07_slot_state {
	S07_SLOT_FREE = 0,
	S07_SLOT_POSTED,
	S07_SLOT_SUBMITTED,
	S07_SLOT_DONE,
};

struct stage07_desc {
	dma_addr_t dma_addr;
	u32 data_len;
	u16 state;
	u16 flags;
};

struct stage07_buf_slot {
	struct sk_buff *skb;
	dma_addr_t dma_addr;
	u32 buf_len;
	u32 data_len;
	u16 state;
	u16 id;
};

struct stage07_queue {
	struct stage07_desc *desc;
	struct stage07_buf_slot *slots;
	u16 size;

	/* TX indexes */
	u16 submit_idx;   /* CPU 提交 TX 请求 */
	u16 notify_idx;   /* backend 消费已提交 TX */
	u16 complete_idx; /* CPU/NAPI 回收已完成 TX */

	/* RX indexes */
	u16 post_idx;     /* CPU post 新 RX buffer */
	u16 device_idx;   /* backend 写入 RX buffer */
	u16 consume_idx;  /* CPU/NAPI 消费已完成 RX */

	spinlock_t lock;
};

struct stage07_priv {
	struct net_device *ndev;
	struct napi_struct napi;
	struct dentry *dbg_dir;
	spinlock_t state_lock;
	bool irq_masked;

	struct stage07_queue txq;
	struct stage07_queue rxq;
	u32 rx_buf_size;

	/* queue depth / lifecycle counters */
	u16 tx_inflight;
	u16 tx_done;
	u16 rx_posted;
	u16 rx_ready;

	/* stats */
	atomic64_t open_count;
	atomic64_t stop_count;

	atomic64_t tx_submit_count;
	atomic64_t tx_complete_count;
	atomic64_t tx_packets;
	atomic64_t tx_bytes;
	atomic64_t tx_dropped;
	atomic64_t tx_busy;
	atomic64_t tx_linearize_count;
	atomic64_t tx_dma_map_ok;
	atomic64_t tx_dma_map_fail;
	atomic64_t tx_dma_unmap;

	atomic64_t rx_post_count;
	atomic64_t rx_consume_count;
	atomic64_t rx_refill_count;
	atomic64_t rx_packets;
	atomic64_t rx_bytes;
	atomic64_t rx_dropped;
	atomic64_t rx_dma_map_ok;
	atomic64_t rx_dma_map_fail;
	atomic64_t rx_dma_unmap;
	atomic64_t rx_truncated;
	atomic64_t rx_no_posted;

	atomic64_t irq_count;
	atomic64_t irq_mask_count;
	atomic64_t irq_unmask_count;
	atomic64_t napi_schedule_count;
	atomic64_t napi_poll_count;
	atomic64_t napi_complete_count;
	atomic64_t napi_budget_exhaust_count;
	atomic64_t napi_work_total;

	atomic64_t ring_full_count;
	atomic64_t ring_empty_count;
	atomic64_t device_notify_count;
	atomic64_t device_tx_processed;
	atomic64_t device_rx_produced;

	atomic64_t last_tx_len;
	atomic64_t last_tx_proto;
	atomic64_t last_rx_len;
	atomic64_t last_rx_proto;
};

static char ifname[IFNAMSIZ] = "nds7";
module_param_string(ifname, ifname, sizeof(ifname), 0644);
MODULE_PARM_DESC(ifname, "interface name for stage07 real queue model");

static int ring_size = STAGE07_DEFAULT_RING_SIZE;
module_param(ring_size, int, 0644);
MODULE_PARM_DESC(ring_size, "TX/RX queue depth");

static int napi_weight = STAGE07_DEFAULT_NAPI_WEIGHT;
module_param(napi_weight, int, 0644);
MODULE_PARM_DESC(napi_weight, "NAPI poll weight");

static int rx_buf_size = STAGE07_DEFAULT_RX_BUF_SIZE;
module_param(rx_buf_size, int, 0644);
MODULE_PARM_DESC(rx_buf_size, "RX buffer size for posted RX slots");

static struct net_device *stage07_dev;

static inline u16 stage07_next_idx(u16 idx, u16 size)
{
	return (u16)((idx + 1) % size);
}

static const char *stage07_state_name(u16 state)
{
	switch (state) {
	case S07_SLOT_FREE:
		return "FREE";
	case S07_SLOT_POSTED:
		return "POSTED";
	case S07_SLOT_SUBMITTED:
		return "SUBMITTED";
	case S07_SLOT_DONE:
		return "DONE";
	default:
		return "?";
	}
}

static int stage07_prepare_dma_caps(struct net_device *ndev)
{
	int ret;

	ndev->dev.coherent_dma_mask = DMA_BIT_MASK(64);
	ndev->dev.dma_mask = &ndev->dev.coherent_dma_mask;
	ret = dma_set_mask_and_coherent(&ndev->dev, DMA_BIT_MASK(64));
	if (ret)
		ret = dma_set_mask_and_coherent(&ndev->dev, DMA_BIT_MASK(32));
	return ret;
}

static void stage07_raise_irq(struct stage07_priv *priv)
{
	bool do_schedule = false;
	unsigned long flags;

	spin_lock_irqsave(&priv->state_lock, flags);
	if (!priv->irq_masked) {
		priv->irq_masked = true;
		do_schedule = true;
	}
	spin_unlock_irqrestore(&priv->state_lock, flags);

	if (!do_schedule)
		return;

	atomic64_inc(&priv->irq_count);
	atomic64_inc(&priv->irq_mask_count);
	atomic64_inc(&priv->napi_schedule_count);
	napi_schedule(&priv->napi);
}

static int stage07_post_rx_slot(struct stage07_priv *priv, u16 idx)
{
	struct stage07_buf_slot *slot = &priv->rxq.slots[idx];
	struct stage07_desc *desc = &priv->rxq.desc[idx];
	struct sk_buff *skb;
	dma_addr_t dma_addr;
	unsigned long flags;

	skb = netdev_alloc_skb_ip_align(priv->ndev, priv->rx_buf_size);
	if (!skb) {
		atomic64_inc(&priv->rx_dma_map_fail);
		return -ENOMEM;
	}

	dma_addr = dma_map_single(&priv->ndev->dev, skb->data, priv->rx_buf_size,
				  DMA_FROM_DEVICE);
	if (dma_mapping_error(&priv->ndev->dev, dma_addr)) {
		dev_kfree_skb_any(skb);
		atomic64_inc(&priv->rx_dma_map_fail);
		return -EIO;
	}

	dma_sync_single_for_device(&priv->ndev->dev, dma_addr, priv->rx_buf_size,
				   DMA_FROM_DEVICE);
	atomic64_inc(&priv->rx_dma_map_ok);

	spin_lock_irqsave(&priv->state_lock, flags);
	slot->skb = skb;
	slot->dma_addr = dma_addr;
	slot->buf_len = priv->rx_buf_size;
	slot->data_len = 0;
	slot->state = S07_SLOT_POSTED;
	desc->dma_addr = dma_addr;
	desc->data_len = 0;
	desc->state = S07_SLOT_POSTED;
	priv->rx_posted++;
	priv->rxq.post_idx = stage07_next_idx(idx, priv->rxq.size);
	spin_unlock_irqrestore(&priv->state_lock, flags);

	atomic64_inc(&priv->rx_post_count);
	atomic64_inc(&priv->rx_refill_count);
	return 0;
}

static int stage07_refill_one(struct stage07_priv *priv)
{
	u16 idx;
	unsigned long flags;

	spin_lock_irqsave(&priv->state_lock, flags);
	idx = priv->rxq.post_idx;
	if (priv->rxq.slots[idx].state != S07_SLOT_FREE) {
		spin_unlock_irqrestore(&priv->state_lock, flags);
		atomic64_inc(&priv->ring_full_count);
		return -EBUSY;
	}
	spin_unlock_irqrestore(&priv->state_lock, flags);

	return stage07_post_rx_slot(priv, idx);
}

static void stage07_reset_queue_state(struct stage07_priv *priv)
{
	unsigned long flags;

	spin_lock_irqsave(&priv->state_lock, flags);
	priv->txq.submit_idx = 0;
	priv->txq.notify_idx = 0;
	priv->txq.complete_idx = 0;
	priv->rxq.post_idx = 0;
	priv->rxq.device_idx = 0;
	priv->rxq.consume_idx = 0;
	priv->tx_inflight = 0;
	priv->tx_done = 0;
	priv->rx_posted = 0;
	priv->rx_ready = 0;
	priv->irq_masked = false;
	spin_unlock_irqrestore(&priv->state_lock, flags);
}

static void stage07_kick_device(struct stage07_priv *priv)
{
	bool produced = false;
	unsigned long flags;

	atomic64_inc(&priv->device_notify_count);

	spin_lock_irqsave(&priv->state_lock, flags);
	while (priv->txq.notify_idx != priv->txq.submit_idx && priv->rx_posted > 0) {
		struct stage07_desc *txd = &priv->txq.desc[priv->txq.notify_idx];
		struct stage07_buf_slot *txs = &priv->txq.slots[priv->txq.notify_idx];
		struct stage07_desc *rxd = &priv->rxq.desc[priv->rxq.device_idx];
		struct stage07_buf_slot *rxs = &priv->rxq.slots[priv->rxq.device_idx];
		u32 copy_len;

		if (txd->state != S07_SLOT_SUBMITTED || txs->state != S07_SLOT_SUBMITTED)
			break;
		if (rxd->state != S07_SLOT_POSTED || rxs->state != S07_SLOT_POSTED || !rxs->skb)
			break;

		copy_len = min_t(u32, txd->data_len, rxs->buf_len);
		if (copy_len < txd->data_len)
			atomic64_inc(&priv->rx_truncated);

		dma_sync_single_for_device(&priv->ndev->dev, rxs->dma_addr, rxs->buf_len,
					   DMA_FROM_DEVICE);
		memcpy(rxs->skb->data, txs->skb->data, copy_len);
		dma_sync_single_for_cpu(&priv->ndev->dev, rxs->dma_addr, copy_len,
					DMA_FROM_DEVICE);

		rxs->data_len = copy_len;
		rxs->state = S07_SLOT_DONE;
		rxd->data_len = copy_len;
		rxd->state = S07_SLOT_DONE;
		priv->rx_ready++;
		if (priv->rx_posted > 0)
			priv->rx_posted--;
		priv->rxq.device_idx = stage07_next_idx(priv->rxq.device_idx, priv->rxq.size);
		atomic64_inc(&priv->device_rx_produced);

		txs->state = S07_SLOT_DONE;
		txd->state = S07_SLOT_DONE;
		priv->tx_done++;
		priv->txq.notify_idx = stage07_next_idx(priv->txq.notify_idx, priv->txq.size);
		atomic64_inc(&priv->device_tx_processed);

		produced = true;
	}
	if (priv->txq.notify_idx != priv->txq.submit_idx && priv->rx_posted == 0)
		atomic64_inc(&priv->rx_no_posted);
	spin_unlock_irqrestore(&priv->state_lock, flags);

	if (produced)
		stage07_raise_irq(priv);
}

static int stage07_complete_tx_one(struct stage07_priv *priv)
{
	struct stage07_buf_slot saved = { 0 };
	u16 idx;
	unsigned long flags;

	spin_lock_irqsave(&priv->state_lock, flags);
	if (!priv->tx_done) {
		spin_unlock_irqrestore(&priv->state_lock, flags);
		return 0;
	}

	idx = priv->txq.complete_idx;
	if (priv->txq.desc[idx].state != S07_SLOT_DONE ||
	    priv->txq.slots[idx].state != S07_SLOT_DONE ||
	    !priv->txq.slots[idx].skb) {
		spin_unlock_irqrestore(&priv->state_lock, flags);
		return 0;
	}

	saved = priv->txq.slots[idx];
	priv->txq.slots[idx].skb = NULL;
	priv->txq.slots[idx].dma_addr = 0;
	priv->txq.slots[idx].buf_len = 0;
	priv->txq.slots[idx].data_len = 0;
	priv->txq.slots[idx].state = S07_SLOT_FREE;
	priv->txq.desc[idx].dma_addr = 0;
	priv->txq.desc[idx].data_len = 0;
	priv->txq.desc[idx].state = S07_SLOT_FREE;
	priv->txq.complete_idx = stage07_next_idx(priv->txq.complete_idx, priv->txq.size);
	priv->tx_done--;
	if (priv->tx_inflight > 0)
		priv->tx_inflight--;
	spin_unlock_irqrestore(&priv->state_lock, flags);

	dma_unmap_single(&priv->ndev->dev, saved.dma_addr, saved.data_len, DMA_TO_DEVICE);
	atomic64_inc(&priv->tx_dma_unmap);
	atomic64_inc(&priv->tx_complete_count);
	dev_consume_skb_any(saved.skb);

	if (netif_queue_stopped(priv->ndev))
		netif_wake_queue(priv->ndev);
	return 1;
}

static int stage07_consume_rx_one(struct stage07_priv *priv)
{
	struct stage07_buf_slot saved = { 0 };
	u16 idx;
	__be16 proto;
	unsigned long flags;
	int rc;

	spin_lock_irqsave(&priv->state_lock, flags);
	if (!priv->rx_ready) {
		spin_unlock_irqrestore(&priv->state_lock, flags);
		return 0;
	}

	idx = priv->rxq.consume_idx;
	if (priv->rxq.desc[idx].state != S07_SLOT_DONE ||
	    priv->rxq.slots[idx].state != S07_SLOT_DONE ||
	    !priv->rxq.slots[idx].skb) {
		spin_unlock_irqrestore(&priv->state_lock, flags);
		return 0;
	}

	saved = priv->rxq.slots[idx];
	priv->rxq.slots[idx].skb = NULL;
	priv->rxq.slots[idx].dma_addr = 0;
	priv->rxq.slots[idx].buf_len = 0;
	priv->rxq.slots[idx].data_len = 0;
	priv->rxq.slots[idx].state = S07_SLOT_FREE;
	priv->rxq.desc[idx].dma_addr = 0;
	priv->rxq.desc[idx].data_len = 0;
	priv->rxq.desc[idx].state = S07_SLOT_FREE;
	priv->rxq.consume_idx = stage07_next_idx(priv->rxq.consume_idx, priv->rxq.size);
	if (priv->rx_ready > 0)
		priv->rx_ready--;
	spin_unlock_irqrestore(&priv->state_lock, flags);

	dma_unmap_single(&priv->ndev->dev, saved.dma_addr, saved.buf_len, DMA_FROM_DEVICE);
	atomic64_inc(&priv->rx_dma_unmap);
	skb_put(saved.skb, saved.data_len);
	proto = eth_type_trans(saved.skb, priv->ndev);
	rc = netif_receive_skb(saved.skb);
	(void)rc;
	atomic64_inc(&priv->rx_consume_count);
	atomic64_inc(&priv->rx_packets);
	atomic64_add(saved.data_len, &priv->rx_bytes);
	atomic64_set(&priv->last_rx_len, saved.data_len);
	atomic64_set(&priv->last_rx_proto, ntohs(proto));

	if (stage07_refill_one(priv))
		atomic64_inc(&priv->rx_dropped);
	return 1;
}

static int stage07_poll(struct napi_struct *napi, int budget)
{
	struct stage07_priv *priv = container_of(napi, struct stage07_priv, napi);
	int work_done = 0;
	bool budget_exhausted = false;
	bool more_rx = false;
	unsigned long flags;

	atomic64_inc(&priv->napi_poll_count);

	while (stage07_complete_tx_one(priv))
		;

	while (work_done < budget && stage07_consume_rx_one(priv))
		work_done++;

	atomic64_add(work_done, &priv->napi_work_total);
	if (work_done == budget) {
		budget_exhausted = true;
		atomic64_inc(&priv->napi_budget_exhaust_count);
	}

	spin_lock_irqsave(&priv->state_lock, flags);
	more_rx = priv->rx_ready > 0;
	if (!more_rx) {
		napi_complete_done(napi, work_done);
		priv->irq_masked = false;
	}
	spin_unlock_irqrestore(&priv->state_lock, flags);

	if (!more_rx) {
		atomic64_inc(&priv->napi_complete_count);
		atomic64_inc(&priv->irq_unmask_count);
	}

	if (!budget_exhausted && !more_rx && priv->tx_done)
		stage07_raise_irq(priv);

	return work_done;
}

static netdev_tx_t stage07_xmit(struct sk_buff *skb, struct net_device *ndev)
{
	struct stage07_priv *priv = netdev_priv(ndev);
	struct stage07_desc *txd;
	struct stage07_buf_slot *txs;
	dma_addr_t tx_dma;
	u16 idx;
	unsigned long flags;

	if (unlikely(skb_is_nonlinear(skb))) {
		if (skb_linearize(skb)) {
			atomic64_inc(&priv->tx_dropped);
			dev_kfree_skb_any(skb);
			return NETDEV_TX_OK;
		}
		atomic64_inc(&priv->tx_linearize_count);
	}

	tx_dma = dma_map_single(&ndev->dev, skb->data, skb->len, DMA_TO_DEVICE);
	if (dma_mapping_error(&ndev->dev, tx_dma)) {
		atomic64_inc(&priv->tx_dma_map_fail);
		atomic64_inc(&priv->tx_dropped);
		dev_kfree_skb_any(skb);
		return NETDEV_TX_OK;
	}
	atomic64_inc(&priv->tx_dma_map_ok);
	dma_sync_single_for_device(&ndev->dev, tx_dma, skb->len, DMA_TO_DEVICE);

	spin_lock_irqsave(&priv->state_lock, flags);
	if (priv->tx_inflight >= priv->txq.size) {
		spin_unlock_irqrestore(&priv->state_lock, flags);
		dma_unmap_single(&ndev->dev, tx_dma, skb->len, DMA_TO_DEVICE);
		atomic64_inc(&priv->tx_dma_unmap);
		atomic64_inc(&priv->tx_busy);
		atomic64_inc(&priv->ring_full_count);
		netif_stop_queue(ndev);
		return NETDEV_TX_BUSY;
	}

	idx = priv->txq.submit_idx;
	txd = &priv->txq.desc[idx];
	txs = &priv->txq.slots[idx];
	if (txd->state != S07_SLOT_FREE || txs->state != S07_SLOT_FREE) {
		spin_unlock_irqrestore(&priv->state_lock, flags);
		dma_unmap_single(&ndev->dev, tx_dma, skb->len, DMA_TO_DEVICE);
		atomic64_inc(&priv->tx_dma_unmap);
		atomic64_inc(&priv->tx_busy);
		atomic64_inc(&priv->ring_full_count);
		return NETDEV_TX_BUSY;
	}

	txd->dma_addr = tx_dma;
	txd->data_len = skb->len;
	txd->state = S07_SLOT_SUBMITTED;
	txs->skb = skb;
	txs->dma_addr = tx_dma;
	txs->buf_len = skb->len;
	txs->data_len = skb->len;
	txs->state = S07_SLOT_SUBMITTED;
	priv->txq.submit_idx = stage07_next_idx(priv->txq.submit_idx, priv->txq.size);
	priv->tx_inflight++;
	spin_unlock_irqrestore(&priv->state_lock, flags);

	atomic64_inc(&priv->tx_submit_count);
	atomic64_inc(&priv->tx_packets);
	atomic64_add(skb->len, &priv->tx_bytes);
	atomic64_set(&priv->last_tx_len, skb->len);
	atomic64_set(&priv->last_tx_proto, ntohs(skb->protocol));

	stage07_kick_device(priv);
	return NETDEV_TX_OK;
}

static int stage07_open(struct net_device *ndev)
{
	struct stage07_priv *priv = netdev_priv(ndev);

	napi_enable(&priv->napi);
	netif_start_queue(ndev);
	atomic64_inc(&priv->open_count);
	return 0;
}

static int stage07_stop(struct net_device *ndev)
{
	struct stage07_priv *priv = netdev_priv(ndev);

	netif_stop_queue(ndev);
	napi_disable(&priv->napi);
	atomic64_inc(&priv->stop_count);
	return 0;
}

static void stage07_get_stats64(struct net_device *ndev,
				struct rtnl_link_stats64 *stats)
{
	struct stage07_priv *priv = netdev_priv(ndev);

	stats->tx_packets = atomic64_read(&priv->tx_packets);
	stats->tx_bytes = atomic64_read(&priv->tx_bytes);
	stats->tx_dropped = atomic64_read(&priv->tx_dropped);
	stats->rx_packets = atomic64_read(&priv->rx_packets);
	stats->rx_bytes = atomic64_read(&priv->rx_bytes);
	stats->rx_dropped = atomic64_read(&priv->rx_dropped);
}

static const struct net_device_ops stage07_netdev_ops = {
	.ndo_open		= stage07_open,
	.ndo_stop		= stage07_stop,
	.ndo_start_xmit		= stage07_xmit,
	.ndo_get_stats64	= stage07_get_stats64,
};

static int stage07_stats_show(struct seq_file *m, void *v)
{
	struct net_device *ndev = m->private;
	struct stage07_priv *priv = netdev_priv(ndev);

	seq_printf(m, "ifname=%s\n", ndev->name);
	seq_printf(m, "ring_size=%u\n", priv->txq.size);
	seq_printf(m, "rx_buf_size=%u\n", priv->rx_buf_size);
	seq_printf(m, "tx_inflight=%u\n", priv->tx_inflight);
	seq_printf(m, "tx_done=%u\n", priv->tx_done);
	seq_printf(m, "rx_posted=%u\n", priv->rx_posted);
	seq_printf(m, "rx_ready=%u\n", priv->rx_ready);
	seq_printf(m, "open_count=%lld\n", atomic64_read(&priv->open_count));
	seq_printf(m, "stop_count=%lld\n", atomic64_read(&priv->stop_count));
	seq_printf(m, "tx_submit_count=%lld\n", atomic64_read(&priv->tx_submit_count));
	seq_printf(m, "tx_complete_count=%lld\n", atomic64_read(&priv->tx_complete_count));
	seq_printf(m, "tx_packets=%lld\n", atomic64_read(&priv->tx_packets));
	seq_printf(m, "tx_bytes=%lld\n", atomic64_read(&priv->tx_bytes));
	seq_printf(m, "tx_dropped=%lld\n", atomic64_read(&priv->tx_dropped));
	seq_printf(m, "tx_busy=%lld\n", atomic64_read(&priv->tx_busy));
	seq_printf(m, "tx_linearize_count=%lld\n", atomic64_read(&priv->tx_linearize_count));
	seq_printf(m, "tx_dma_map_ok=%lld\n", atomic64_read(&priv->tx_dma_map_ok));
	seq_printf(m, "tx_dma_map_fail=%lld\n", atomic64_read(&priv->tx_dma_map_fail));
	seq_printf(m, "tx_dma_unmap=%lld\n", atomic64_read(&priv->tx_dma_unmap));
	seq_printf(m, "rx_post_count=%lld\n", atomic64_read(&priv->rx_post_count));
	seq_printf(m, "rx_consume_count=%lld\n", atomic64_read(&priv->rx_consume_count));
	seq_printf(m, "rx_refill_count=%lld\n", atomic64_read(&priv->rx_refill_count));
	seq_printf(m, "rx_packets=%lld\n", atomic64_read(&priv->rx_packets));
	seq_printf(m, "rx_bytes=%lld\n", atomic64_read(&priv->rx_bytes));
	seq_printf(m, "rx_dropped=%lld\n", atomic64_read(&priv->rx_dropped));
	seq_printf(m, "rx_dma_map_ok=%lld\n", atomic64_read(&priv->rx_dma_map_ok));
	seq_printf(m, "rx_dma_map_fail=%lld\n", atomic64_read(&priv->rx_dma_map_fail));
	seq_printf(m, "rx_dma_unmap=%lld\n", atomic64_read(&priv->rx_dma_unmap));
	seq_printf(m, "rx_truncated=%lld\n", atomic64_read(&priv->rx_truncated));
	seq_printf(m, "rx_no_posted=%lld\n", atomic64_read(&priv->rx_no_posted));
	seq_printf(m, "irq_count=%lld\n", atomic64_read(&priv->irq_count));
	seq_printf(m, "irq_mask_count=%lld\n", atomic64_read(&priv->irq_mask_count));
	seq_printf(m, "irq_unmask_count=%lld\n", atomic64_read(&priv->irq_unmask_count));
	seq_printf(m, "napi_schedule_count=%lld\n", atomic64_read(&priv->napi_schedule_count));
	seq_printf(m, "napi_poll_count=%lld\n", atomic64_read(&priv->napi_poll_count));
	seq_printf(m, "napi_complete_count=%lld\n", atomic64_read(&priv->napi_complete_count));
	seq_printf(m, "napi_budget_exhaust_count=%lld\n", atomic64_read(&priv->napi_budget_exhaust_count));
	seq_printf(m, "napi_work_total=%lld\n", atomic64_read(&priv->napi_work_total));
	seq_printf(m, "ring_full_count=%lld\n", atomic64_read(&priv->ring_full_count));
	seq_printf(m, "ring_empty_count=%lld\n", atomic64_read(&priv->ring_empty_count));
	seq_printf(m, "device_notify_count=%lld\n", atomic64_read(&priv->device_notify_count));
	seq_printf(m, "device_tx_processed=%lld\n", atomic64_read(&priv->device_tx_processed));
	seq_printf(m, "device_rx_produced=%lld\n", atomic64_read(&priv->device_rx_produced));
	seq_printf(m, "last_tx_len=%lld\n", atomic64_read(&priv->last_tx_len));
	seq_printf(m, "last_tx_proto=%#llx\n", atomic64_read(&priv->last_tx_proto));
	seq_printf(m, "last_rx_len=%lld\n", atomic64_read(&priv->last_rx_len));
	seq_printf(m, "last_rx_proto=%#llx\n", atomic64_read(&priv->last_rx_proto));
	return 0;
}

static int stage07_stats_open(struct inode *inode, struct file *file)
{
	return single_open(file, stage07_stats_show, inode->i_private);
}

static const struct file_operations stage07_stats_fops = {
	.owner = THIS_MODULE,
	.open = stage07_stats_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};

static int stage07_queues_show(struct seq_file *m, void *v)
{
	struct net_device *ndev = m->private;
	struct stage07_priv *priv = netdev_priv(ndev);
	u16 i;

	seq_printf(m,
		   "TX submit=%u notify=%u complete=%u inflight=%u done=%u\n",
		   priv->txq.submit_idx, priv->txq.notify_idx, priv->txq.complete_idx,
		   priv->tx_inflight, priv->tx_done);
	for (i = 0; i < min_t(u16, priv->txq.size, STAGE07_MAX_QUEUE_DUMP); ++i) {
		seq_printf(m,
			   "  tx[%u] desc=%s slot=%s len=%u skb=%p\n",
			   i,
			   stage07_state_name(priv->txq.desc[i].state),
			   stage07_state_name(priv->txq.slots[i].state),
			   priv->txq.desc[i].data_len,
			   priv->txq.slots[i].skb);
	}

	seq_printf(m,
		   "RX post=%u device=%u consume=%u posted=%u ready=%u\n",
		   priv->rxq.post_idx, priv->rxq.device_idx, priv->rxq.consume_idx,
		   priv->rx_posted, priv->rx_ready);
	for (i = 0; i < min_t(u16, priv->rxq.size, STAGE07_MAX_QUEUE_DUMP); ++i) {
		seq_printf(m,
			   "  rx[%u] desc=%s slot=%s len=%u skb=%p\n",
			   i,
			   stage07_state_name(priv->rxq.desc[i].state),
			   stage07_state_name(priv->rxq.slots[i].state),
			   priv->rxq.desc[i].data_len,
			   priv->rxq.slots[i].skb);
	}
	return 0;
}

static int stage07_queues_open(struct inode *inode, struct file *file)
{
	return single_open(file, stage07_queues_show, inode->i_private);
}

static const struct file_operations stage07_queues_fops = {
	.owner = THIS_MODULE,
	.open = stage07_queues_open,
	.read = seq_read,
	.llseek = seq_lseek,
	.release = single_release,
};

static void stage07_debugfs_init(struct stage07_priv *priv)
{
	priv->dbg_dir = debugfs_create_dir(DRV_NAME, NULL);
	if (IS_ERR_OR_NULL(priv->dbg_dir)) {
		priv->dbg_dir = NULL;
		return;
	}
	debugfs_create_file("stats", 0444, priv->dbg_dir, priv->ndev, &stage07_stats_fops);
	debugfs_create_file("queues", 0444, priv->dbg_dir, priv->ndev, &stage07_queues_fops);
}

static void stage07_cleanup_rx_queue(struct stage07_priv *priv)
{
	u16 i;

	for (i = 0; i < priv->rxq.size; ++i) {
		struct stage07_buf_slot *slot = &priv->rxq.slots[i];
		if (slot->skb) {
			dma_unmap_single(&priv->ndev->dev, slot->dma_addr,
					 slot->buf_len ?: priv->rx_buf_size,
					 DMA_FROM_DEVICE);
			dev_kfree_skb_any(slot->skb);
		}
		slot->skb = NULL;
		slot->dma_addr = 0;
		slot->buf_len = 0;
		slot->data_len = 0;
		slot->state = S07_SLOT_FREE;
		priv->rxq.desc[i].dma_addr = 0;
		priv->rxq.desc[i].data_len = 0;
		priv->rxq.desc[i].state = S07_SLOT_FREE;
	}
}

static void stage07_cleanup_tx_queue(struct stage07_priv *priv)
{
	u16 i;

	for (i = 0; i < priv->txq.size; ++i) {
		struct stage07_buf_slot *slot = &priv->txq.slots[i];
		if (slot->skb) {
			dma_unmap_single(&priv->ndev->dev, slot->dma_addr,
					 slot->data_len, DMA_TO_DEVICE);
			dev_kfree_skb_any(slot->skb);
		}
		slot->skb = NULL;
		slot->dma_addr = 0;
		slot->buf_len = 0;
		slot->data_len = 0;
		slot->state = S07_SLOT_FREE;
		priv->txq.desc[i].dma_addr = 0;
		priv->txq.desc[i].data_len = 0;
		priv->txq.desc[i].state = S07_SLOT_FREE;
	}
}

static int stage07_alloc_queues(struct stage07_priv *priv)
{
	size_t qsz = sizeof(struct stage07_desc) * priv->txq.size;
	size_t ssz = sizeof(struct stage07_buf_slot) * priv->txq.size;
	u16 i;
	int ret;

	priv->txq.desc = kcalloc(priv->txq.size, sizeof(*priv->txq.desc), GFP_KERNEL);
	priv->txq.slots = kcalloc(priv->txq.size, sizeof(*priv->txq.slots), GFP_KERNEL);
	priv->rxq.desc = kcalloc(priv->rxq.size, sizeof(*priv->rxq.desc), GFP_KERNEL);
	priv->rxq.slots = kcalloc(priv->rxq.size, sizeof(*priv->rxq.slots), GFP_KERNEL);
	if (!priv->txq.desc || !priv->txq.slots || !priv->rxq.desc || !priv->rxq.slots)
		return -ENOMEM;

	memset(priv->txq.desc, 0, qsz);
	memset(priv->txq.slots, 0, ssz);
	memset(priv->rxq.desc, 0, qsz);
	memset(priv->rxq.slots, 0, ssz);
	for (i = 0; i < priv->txq.size; ++i) {
		priv->txq.slots[i].id = i;
		priv->rxq.slots[i].id = i;
	}

	stage07_reset_queue_state(priv);
	for (i = 0; i < priv->rxq.size; ++i) {
		ret = stage07_post_rx_slot(priv, i);
		if (ret)
			return ret;
	}
	return 0;
}

static void stage07_free_queues(struct stage07_priv *priv)
{
	stage07_cleanup_tx_queue(priv);
	stage07_cleanup_rx_queue(priv);
	kfree(priv->txq.desc);
	kfree(priv->txq.slots);
	kfree(priv->rxq.desc);
	kfree(priv->rxq.slots);
	priv->txq.desc = NULL;
	priv->txq.slots = NULL;
	priv->rxq.desc = NULL;
	priv->rxq.slots = NULL;
}

static void stage07_setup(struct net_device *ndev)
{
	ether_setup(ndev);
	ndev->netdev_ops = &stage07_netdev_ops;
	ndev->flags |= IFF_NOARP;
	ndev->features |= NETIF_F_HIGHDMA;
	ndev->watchdog_timeo = 5 * HZ;
	eth_hw_addr_random(ndev);
}

static int __init stage07_init(void)
{
	struct stage07_priv *priv;
	int ret;

	if (ring_size < 8)
		ring_size = 8;
	if (napi_weight < 8)
		napi_weight = 8;
	if (rx_buf_size < 256)
		rx_buf_size = 256;

	stage07_dev = alloc_netdev(sizeof(struct stage07_priv), ifname,
				   NET_NAME_UNKNOWN, stage07_setup);
	if (!stage07_dev)
		return -ENOMEM;

	priv = netdev_priv(stage07_dev);
	priv->ndev = stage07_dev;
	priv->rx_buf_size = rx_buf_size;
	priv->txq.size = ring_size;
	priv->rxq.size = ring_size;
	spin_lock_init(&priv->state_lock);
	spin_lock_init(&priv->txq.lock);
	spin_lock_init(&priv->rxq.lock);

	ret = stage07_prepare_dma_caps(stage07_dev);
	if (ret)
		netdev_warn(stage07_dev, "dma_set_mask_and_coherent failed: %d\n", ret);

	STAGE07_NETIF_NAPI_ADD(stage07_dev, &priv->napi, stage07_poll, napi_weight);
	ret = stage07_alloc_queues(priv);
	if (ret)
		goto err_napi;

	ret = register_netdev(stage07_dev);
	if (ret)
		goto err_queue;

	stage07_debugfs_init(priv);
	pr_info("stage07 loaded: ifname=%s ring_size=%d napi_weight=%d rx_buf_size=%d\n",
		stage07_dev->name, ring_size, napi_weight, rx_buf_size);
	return 0;

err_queue:
	stage07_free_queues(priv);
err_napi:
	netif_napi_del(&priv->napi);
	free_netdev(stage07_dev);
	stage07_dev = NULL;
	return ret;
}

static void __exit stage07_exit(void)
{
	struct stage07_priv *priv;

	if (!stage07_dev)
		return;

	priv = netdev_priv(stage07_dev);
	unregister_netdev(stage07_dev);
	debugfs_remove_recursive(priv->dbg_dir);
	netif_napi_del(&priv->napi);
	stage07_free_queues(priv);
	free_netdev(stage07_dev);
	stage07_dev = NULL;
	pr_info("stage07 unloaded\n");
}

module_init(stage07_init);
module_exit(stage07_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("OpenAI + user project");
MODULE_DESCRIPTION("stage07 real queue model v1");
