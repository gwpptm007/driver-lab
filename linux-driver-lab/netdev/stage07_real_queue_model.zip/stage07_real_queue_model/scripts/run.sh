#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
KO="$ROOT_DIR/output/netdev_stage07.ko"
ACTION=${1:-reload}
IFNAME=${IFNAME:-nds7}
RING_SIZE=${RING_SIZE:-128}
NAPI_WEIGHT=${NAPI_WEIGHT:-32}
RX_BUF_SIZE=${RX_BUF_SIZE:-2048}

is_loaded() {
    lsmod | awk '{print $1}' | grep -qx netdev_stage07
}

case "$ACTION" in
    load)
        test -f "$KO" || { echo "[stage07] missing $KO, run scripts/build.sh first" >&2; exit 1; }
        if is_loaded; then
            echo "[stage07] netdev_stage07 already loaded"
            exit 0
        fi
        sudo insmod "$KO" ifname="$IFNAME" ring_size="$RING_SIZE" napi_weight="$NAPI_WEIGHT" rx_buf_size="$RX_BUF_SIZE"
        sleep 1
        sudo ip link set dev "$IFNAME" up || true
        ip -details link show "$IFNAME" || true
        ;;
    unload)
        if is_loaded; then
            sudo rmmod netdev_stage07
            echo "[stage07] unloaded"
        else
            echo "[stage07] module not loaded"
        fi
        ;;
    reload)
        "$0" unload || true
        "$0" load
        ;;
    status)
        is_loaded && echo "[stage07] loaded" || echo "[stage07] not loaded"
        ip -details link show "$IFNAME" || true
        ;;
    *)
        echo "Usage: $0 [load|unload|reload|status]" >&2
        exit 1
        ;;
esac
