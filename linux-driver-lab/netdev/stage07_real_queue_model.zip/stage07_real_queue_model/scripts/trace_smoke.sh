#!/usr/bin/env bash
set -euo pipefail
STAMP=$(date +%Y%m%d-%H%M%S)
OUT=${1:-stage07_dmesg_${STAMP}.log}
sudo dmesg | grep -E 'stage07|netdev_stage07' | tail -n 200 | tee "$OUT"
echo "[stage07] trace log -> $OUT"
