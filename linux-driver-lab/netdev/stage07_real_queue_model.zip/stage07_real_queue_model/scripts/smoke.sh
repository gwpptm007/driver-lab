#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
TOOLS_DIR="$ROOT_DIR/tools"
IFNAME=${IFNAME:-nds7}
ETHERTYPE=${ETHERTYPE:-0x88B7}
SMOKE_COUNT=${SMOKE_COUNT:-32}
SMOKE_TIMEOUT_SEC=${SMOKE_TIMEOUT_SEC:-5}
TIMEOUT_BIN=${TIMEOUT_BIN:-timeout}
STAMP=$(date +%Y%m%d-%H%M%S)
LOG_DIR="$ROOT_DIR/records/$STAMP-stage07-smoke"
SEND_TOOL="$TOOLS_DIR/send_stage07_frame"
RECV_TOOL="$TOOLS_DIR/recv_stage07_frame"

mkdir -p "$LOG_DIR"

test -x "$SEND_TOOL" || { echo "[stage07] missing $SEND_TOOL, run scripts/build.sh first" >&2; exit 1; }
test -x "$RECV_TOOL" || { echo "[stage07] missing $RECV_TOOL, run scripts/build.sh first" >&2; exit 1; }
lsmod | awk '{print $1}' | grep -qx netdev_stage07 || { echo "[stage07] module netdev_stage07 is not loaded" >&2; exit 1; }

sudo ip link set dev "$IFNAME" up
ip -details link show "$IFNAME" | tee "$LOG_DIR/ip_link_before.txt"

sudo "$TIMEOUT_BIN" "$SMOKE_TIMEOUT_SEC" \
    "$RECV_TOOL" "$IFNAME" "$ETHERTYPE" "$SMOKE_COUNT" "$SMOKE_TIMEOUT_SEC" \
    > "$LOG_DIR/recv.txt" 2>&1 &
RECV_PID=$!
sleep 1

sudo "$SEND_TOOL" "$IFNAME" "hello_stage07_queue" "$ETHERTYPE" "$SMOKE_COUNT" 0 \
    | tee "$LOG_DIR/send.txt"
wait "$RECV_PID" || true
sleep 1

ip -s link show "$IFNAME" | tee "$LOG_DIR/ip_link_after.txt"
if [[ -f /sys/kernel/debug/netdev_stage07/stats ]]; then
    sudo cat /sys/kernel/debug/netdev_stage07/stats | tee "$LOG_DIR/debugfs_stats.txt"
fi
if [[ -f /sys/kernel/debug/netdev_stage07/queues ]]; then
    sudo cat /sys/kernel/debug/netdev_stage07/queues | tee "$LOG_DIR/debugfs_queues.txt"
fi
sudo dmesg | tail -n 120 | tee "$LOG_DIR/dmesg_tail.txt" >/dev/null

echo "[stage07] smoke record -> $LOG_DIR"
